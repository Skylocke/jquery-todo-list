console.log('woo');
$(document).ready(function(){
    $("#targetForm").submit(function(e){
        return false;
    });

});

function addItem() {
    // Step 1: Create img and li elements.
    var img = $('<img src="img/red_close_button.png" class="remove">');
    var li = $("<li>");

    // Step 2: add text to the li element
    li.text($('#entry').val());

    // Step 3: Attach the img to the li, and the li to the list.
    li.append(img);
    $('#theList').append(li);

    // attach click handlers.
    $('li').children('img').click(removeItem);
}

function removeItem() {
    $(this).parent('li').remove();
}
